<template>
  <div>
    Bạn có muốn hỗ trợ cùng bọn mình? 🍍 Bạn có thể chia sẻ link đăng ký nhận
    rau, để nhiều khu vực cách ly, phong toả, bệnh viện, người yếu thế có rau
    miễn phí: https://bit.ly/dangkychuyenrauvuive 🍍 Bạn có thể đăng ký làm tình
    nguyện viên tại: https://bit.ly/dkTinhNguyenVien 🍍 Bạn có thể mời bạn bè
    like Fanpage, chia sẻ các bài đăng, hoặc add frame (tạo hình nền) với từ
    khoá là "Chuyenrau" để nhiều người biết đến chương trình hơn. 🍍 Bạn có thể
    chung tay cùng bọn mình, gây quỹ cho 10 tấn đến 20 tấn rau mỗi ngày, miễn
    phí tại các khu phong toả: * Tên: Tạ Thuỳ Trang * Số TK: 555 5555 123 (VP
    Bank, Chi nhánh TPHCM) * Số TK: 03804965569 (TP Bank, Chi nhánh Phú Mỹ Hưng)
    * Số TK: 0441000628235 (Vietcombank, chi nhánh Tân Bình) * Ghi chú:
    HoTên_vanchuyen97
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>