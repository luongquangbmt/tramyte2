<template>
  <div class="oxygen-oxygen">
    <div class="oxygen-container">
      <span>{{ text }}</span>
      <svg viewBox="0 0 1024 1024" class="oxygen-icon">
        <path d="M384 690l452-452 60 60-512 512-238-238 60-60z"></path>
      </svg>
      <span>{{ text1 }}</span>
    </div>
    <div class="oxygen-container01">
      <span class="oxygen-text02">{{ text2 }}</span>
      <svg
        viewBox="0 0 877.7142857142857 1024"
        style="fill: #0a66c2"
        class="oxygen-icon02"
      >
        <path
          d="M199.429 357.143v566.286h-188.571v-566.286h188.571zM211.429 182.286c0.571 54.286-40.571 97.714-106.286 97.714v0h-1.143c-63.429 0-104-43.429-104-97.714 0-55.429 42.286-97.714 106.286-97.714 64.571 0 104.571 42.286 105.143 97.714zM877.714 598.857v324.571h-188v-302.857c0-76-27.429-128-95.429-128-52 0-82.857 34.857-96.571 68.571-4.571 12.571-6.286 29.143-6.286 46.286v316h-188c2.286-513.143 0-566.286 0-566.286h188v82.286h-1.143c24.571-38.857 69.143-95.429 170.857-95.429 124 0 216.571 81.143 216.571 254.857z"
        ></path></svg
      ><svg
        viewBox="0 0 877.7142857142857 1024"
        style="fill: #00e676"
        class="oxygen-icon04"
      >
        <path
          d="M562.857 556.571c9.714 0 102.857 48.571 106.857 55.429 1.143 2.857 1.143 6.286 1.143 8.571 0 14.286-4.571 30.286-9.714 43.429-13.143 32-66.286 52.571-98.857 52.571-27.429 0-84-24-108.571-35.429-81.714-37.143-132.571-100.571-181.714-173.143-21.714-32-41.143-71.429-40.571-110.857v-4.571c1.143-37.714 14.857-64.571 42.286-90.286 8.571-8 17.714-12.571 29.714-12.571 6.857 0 13.714 1.714 21.143 1.714 15.429 0 18.286 4.571 24 19.429 4 9.714 33.143 87.429 33.143 93.143 0 21.714-39.429 46.286-39.429 59.429 0 2.857 1.143 5.714 2.857 8.571 12.571 26.857 36.571 57.714 58.286 78.286 26.286 25.143 54.286 41.714 86.286 57.714 4 2.286 8 4 12.571 4 17.143 0 45.714-55.429 60.571-55.429zM446.857 859.429c197.714 0 358.857-161.143 358.857-358.857s-161.143-358.857-358.857-358.857-358.857 161.143-358.857 358.857c0 75.429 24 149.143 68.571 210.286l-45.143 133.143 138.286-44c58.286 38.286 127.429 59.429 197.143 59.429zM446.857 69.714c237.714 0 430.857 193.143 430.857 430.857s-193.143 430.857-430.857 430.857c-72.571 0-144.571-18.286-208.571-53.714l-238.286 76.571 77.714-231.429c-40.571-66.857-61.714-144-61.714-222.286 0-237.714 193.143-430.857 430.857-430.857z"
        ></path></svg
      ><svg viewBox="0 0 1024 1024" style="fill: #0f90f3" class="oxygen-icon06">
        <path
          d="M1024 226.4c-37.6 16.8-78.2 28-120.6 33 43.4-26 76.6-67.2 92.4-116.2-40.6 24-85.6 41.6-133.4 51-38.4-40.8-93-66.2-153.4-66.2-116 0-210 94-210 210 0 16.4 1.8 32.4 5.4 47.8-174.6-8.8-329.4-92.4-433-219.6-18 31-28.4 67.2-28.4 105.6 0 72.8 37 137.2 93.4 174.8-34.4-1-66.8-10.6-95.2-26.2 0 0.8 0 1.8 0 2.6 0 101.8 72.4 186.8 168.6 206-17.6 4.8-36.2 7.4-55.4 7.4-13.6 0-26.6-1.4-39.6-3.8 26.8 83.4 104.4 144.2 196.2 146-72 56.4-162.4 90-261 90-17 0-33.6-1-50.2-3 93.2 59.8 203.6 94.4 322.2 94.4 386.4 0 597.8-320.2 597.8-597.8 0-9.2-0.2-18.2-0.6-27.2 41-29.4 76.6-66.4 104.8-108.6z"
        ></path>
      </svg>
      <svg
        version="1.1"
        id="Capa_1"
        class="oxygen-icon04"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        x="0px"
        y="0px"
        viewBox="0 0 512.007 512.007"
        style="enable-background: new 0 0 512.007 512.007"
        xml:space="preserve"
      >
        <circle style="fill: #E6EFF4" cx="256.003" cy="256.003" r="256.003" />
        <path
          style="fill: #B6D1DD"
          d="M385.581,107.256L385.581,107.256c-5.101-5.102-12.148-8.258-19.932-8.258H146.354
	c-15.567,0-28.187,12.619-28.187,28.187v219.295c0,7.785,3.156,14.832,8.258,19.933l0,0l145.105,145.105
	C405.682,503.489,512.001,392.169,512.001,256c0-8.086-0.393-16.081-1.126-23.976L385.581,107.256z"
        />
        <path
          style="fill: #41A0D7"
          d="M365.647,98.999H146.353c-15.567,0-28.187,12.619-28.187,28.187v219.294
	c0,15.567,12.619,28.187,28.187,28.187h43.971v38.334l53.377-38.334h121.946c15.567,0,28.187-12.619,28.187-28.187V127.185
	C393.834,111.618,381.215,98.999,365.647,98.999z"
        />
        <path
          style="fill: #FFFFFF"
          d="M393.834,340.942v-44.17c-5.73-5.85-13.714-9.484-22.55-9.484h-64.188l86.738-118.175V131.24
	c-4.466-3.988-10.304-6.31-16.5-6.31h-131.2c-17.435,0-31.57,14.135-31.57,31.57s14.135,31.57,31.57,31.57h55.168L212,311.089
	c-5.474,7.539-6.255,17.512-2.024,25.812c4.231,8.3,12.76,13.526,22.077,13.526h139.232
	C380.121,350.426,388.104,346.792,393.834,340.942z"
        />
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
        <g></g>
      </svg>
      <svg
        viewBox="0 0 877.7142857142857 1024"
        style="fill: #0f90f3"
        class="oxygen-icon08"
      >
        <path
          d="M713.143 73.143c90.857 0 164.571 73.714 164.571 164.571v548.571c0 90.857-73.714 164.571-164.571 164.571h-107.429v-340h113.714l17.143-132.571h-130.857v-84.571c0-38.286 10.286-64 65.714-64l69.714-0.571v-118.286c-12-1.714-53.714-5.143-101.714-5.143-101.143 0-170.857 61.714-170.857 174.857v97.714h-114.286v132.571h114.286v340h-304c-90.857 0-164.571-73.714-164.571-164.571v-548.571c0-90.857 73.714-164.571 164.571-164.571h548.571z"
        ></path>
      </svg>
    </div>
    <div class="oxygen-container02">
      <div class="oxygen-container03">
        <span>{{ text3 }}</span>
        <span class="oxygen-text04">{{ text4 }}</span>
        <div class="oxygen-container04">
          <svg viewBox="0 0 1024 1024" class="oxygen-icon10">
            <path
              d="M809.003 291.328l-297.003 171.819-297.003-171.819 275.456-157.397c4.779-2.731 9.899-4.48 15.147-5.333 9.301-1.451 18.987 0.128 27.904 5.291zM491.776 979.669c6.016 3.243 12.928 5.077 20.224 5.077 7.381 0 14.336-1.877 20.395-5.163 15.189-2.475 29.909-7.68 43.392-15.36l298.709-170.709c26.368-15.232 45.269-38.315 55.424-64.597 5.675-14.592 8.619-30.165 8.747-46.251v-341.333c0-20.395-4.821-39.723-13.397-56.917-0.939-3.029-2.219-5.973-3.883-8.832-1.963-3.371-4.267-6.357-6.912-8.96-1.323-1.835-2.731-3.669-4.139-5.419-9.813-12.203-21.845-22.528-35.456-30.507l-299.051-170.88c-26.027-15.019-55.467-19.84-83.328-15.531-15.531 2.432-30.507 7.637-44.288 15.488l-298.709 170.709c-16.341 9.429-29.824 21.888-40.149 36.267-2.56 2.56-4.864 5.547-6.784 8.832-1.664 2.901-2.987 5.888-3.925 8.96-1.707 3.456-3.243 6.955-4.608 10.496-5.632 14.635-8.576 30.208-8.704 45.995v341.632c0.043 30.293 10.581 58.197 28.331 80.128 9.813 12.203 21.845 22.528 35.456 30.507l299.051 170.88c13.824 7.979 28.587 13.099 43.605 15.445zM469.333 537.045v340.949l-277.12-158.336c-4.736-2.773-8.832-6.315-12.16-10.411-5.931-7.381-9.387-16.512-9.387-26.581v-318.379zM554.667 877.995v-340.949l298.667-172.757v318.379c-0.043 5.163-1.067 10.496-2.987 15.445-3.413 8.789-9.6 16.384-18.176 21.333z"
            ></path>
          </svg>
          <span>{{ text9 }}</span>
          <span>{{ text10 }}</span>
        </div>
        <div class="oxygen-container05">
          <svg viewBox="0 0 1024 1024" class="oxygen-icon12">
            <path
              d="M469.333 469.333h-64c-29.483 0-56.064-11.904-75.435-31.232s-31.232-45.952-31.232-75.435 11.904-56.064 31.232-75.435 45.952-31.232 75.435-31.232h64zM554.667 554.667h64c29.483 0 56.064 11.904 75.435 31.232s31.232 45.952 31.232 75.435-11.904 56.064-31.232 75.435-45.952 31.232-75.435 31.232h-64zM725.333 170.667h-170.667v-128c0-23.552-19.115-42.667-42.667-42.667s-42.667 19.115-42.667 42.667v128h-64c-52.992 0-101.077 21.547-135.765 56.235s-56.235 82.773-56.235 135.765 21.547 101.077 56.235 135.765 82.773 56.235 135.765 56.235h64v213.333h-213.333c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667h213.333v128c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-128h64c52.992 0 101.077-21.547 135.765-56.235s56.235-82.773 56.235-135.765-21.547-101.077-56.235-135.765-82.773-56.235-135.765-56.235h-64v-213.333h170.667c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667z"
            ></path>
          </svg>
          <span>{{ text11 }}</span>
          <span>{{ text12 }}</span>
        </div>
      </div>
      <div class="oxygen-container06">
        <div class="oxygen-container07">
          <svg viewBox="0 0 1024 1024" class="oxygen-icon14">
            <path
              d="M282 460q96 186 282 282l94-94q20-20 44-10 72 24 152 24 18 0 30 12t12 30v150q0 18-12 30t-30 12q-300 0-513-213t-213-513q0-18 12-30t30-12h150q18 0 30 12t12 30q0 80 24 152 8 26-10 44z"
            ></path>
          </svg>
          <span>{{ text13 }}</span>
        </div>
        <div class="oxygen-container08">
          <svg viewBox="0 0 1024 1024" class="oxygen-icon16">
            <path
              d="M392.491 580.224c42.325 56.619 103.68 90.709 168.448 100.053s133.248-6.059 189.867-48.384c10.197-7.637 19.84-16 27.947-24.235l127.787-127.744c49.621-51.371 73.472-117.376 72.363-182.827s-27.264-130.603-78.123-179.669c-50.005-48.299-114.731-72.192-179.157-71.808-63.659 0.341-127.275 24.363-176.512 71.808l-73.856 73.429c-16.725 16.597-16.811 43.648-0.171 60.331s43.648 16.811 60.331 0.171l72.917-72.491c32.853-31.659 75.221-47.659 117.76-47.915 43.051-0.256 86.059 15.659 119.381 47.872 33.92 32.768 51.328 76.075 52.096 119.808s-15.147 87.637-47.36 121.003l-128.213 128.256c-4.864 4.949-11.221 10.539-18.261 15.787-37.76 28.245-83.285 38.485-126.592 32.256s-84.096-28.928-112.299-66.688c-14.123-18.859-40.832-22.741-59.733-8.619s-22.741 40.832-8.619 59.733zM631.509 443.776c-42.325-56.619-103.68-90.709-168.448-100.053s-133.291 6.059-189.909 48.384c-10.197 7.637-19.797 16-27.947 24.235l-127.787 127.744c-49.621 51.371-73.472 117.376-72.363 182.827s27.264 130.603 78.123 179.669c50.005 48.299 114.731 72.192 179.157 71.808 63.659-0.341 127.275-24.363 176.512-71.808l73.515-73.515c16.683-16.683 16.683-43.691 0-60.331s-43.691-16.683-60.331 0l-72.363 72.491c-32.853 31.659-75.221 47.659-117.76 47.915-43.051 0.256-86.059-15.659-119.381-47.872-33.92-32.768-51.328-76.075-52.096-119.808s15.147-87.637 47.36-121.003l128.213-128.256c4.864-4.949 11.221-10.539 18.261-15.787 37.76-28.245 83.285-38.485 126.592-32.256s84.096 28.928 112.299 66.688c14.123 18.859 40.832 22.741 59.733 8.619s22.741-40.832 8.619-59.733z"
            ></path>
          </svg>
          <span>{{ text14 }}</span>
        </div>
      </div>
    </div>
    <div class="oxygen-container09">
      <div class="oxygen-container10">
        <span>{{ text5 }}</span>
        <span>{{ text6 }}</span>
      </div>
      <div class="oxygen-container11">
        <div class="oxygen-container12">
          <svg
            viewBox="0 0 914.2857142857142 1024"
            style="fill: #0f90f3"
            class="oxygen-icon18"
          >
            <path
              d="M146.286 768c0-20-16.571-36.571-36.571-36.571-20.571 0-36.571 16.571-36.571 36.571 0 20.571 16 36.571 36.571 36.571 20 0 36.571-16 36.571-36.571zM237.714 475.429v365.714c0 20-16.571 36.571-36.571 36.571h-164.571c-20 0-36.571-16.571-36.571-36.571v-365.714c0-20 16.571-36.571 36.571-36.571h164.571c20 0 36.571 16.571 36.571 36.571zM914.286 475.429c0 30.286-12 62.857-31.429 85.143 6.286 18.286 8.571 35.429 8.571 43.429 1.143 28.571-7.429 55.429-24.571 78.286 6.286 21.143 6.286 44 0 66.857-5.714 21.143-16.571 40-30.857 53.714 3.429 42.857-6.286 77.714-28 103.429-24.571 29.143-62.286 44-112.571 44.571h-73.714c-81.714 0-158.857-26.857-220.571-48-36-12.571-70.286-24.571-90.286-25.143-19.429-0.571-36.571-16.571-36.571-36.571v-366.286c0-18.857 16-34.857 34.857-36.571 21.143-1.714 76-69.714 101.143-102.857 20.571-26.286 40-50.857 57.714-68.571 22.286-22.286 28.571-56.571 35.429-89.714 6.286-33.714 13.143-69.143 37.714-93.143 6.857-6.857 16-10.857 25.714-10.857 128 0 128 102.286 128 146.286 0 46.857-16.571 80-32 109.714-6.286 12.571-12 18.286-16.571 36.571h158.286c59.429 0 109.714 50.286 109.714 109.714z"
            ></path>
          </svg>
          <span>{{ text15 }}</span>
        </div>
        <div class="oxygen-container13">
          <svg
            viewBox="0 0 914.2857142857142 1024"
            style="fill: #da1738"
            class="oxygen-icon20"
          >
            <path
              d="M146.286 329.143c0 20-16.571 36.571-36.571 36.571-20.571 0-36.571-16.571-36.571-36.571 0-20.571 16-36.571 36.571-36.571 20 0 36.571 16 36.571 36.571zM237.714 621.714v-365.714c0-20-16.571-36.571-36.571-36.571h-164.571c-20 0-36.571 16.571-36.571 36.571v365.714c0 20 16.571 36.571 36.571 36.571h164.571c20 0 36.571-16.571 36.571-36.571zM882.857 536.571c19.429 21.714 31.429 54.857 31.429 85.143-0.571 59.429-50.286 109.714-109.714 109.714h-158.286c4.571 18.286 10.286 24 16.571 36.571 14.857 29.714 32 62.857 32 109.714 0 44 0 146.286-128 146.286-9.714 0-18.857-4-25.714-10.857-24.571-24-31.429-59.429-37.714-93.143-6.857-33.143-13.143-67.429-35.429-89.714-17.714-17.714-37.143-42.286-57.714-68.571-25.143-33.143-80-101.143-101.143-102.857-18.857-1.714-34.857-17.714-34.857-36.571v-366.286c0-20 17.143-36 36.571-36.571 20-0.571 54.286-12.571 90.286-25.143 61.714-21.143 138.857-48 220.571-48h73.714c50.286 0.571 88 15.429 112.571 44.571 21.714 25.714 31.429 60.571 28 103.429 14.286 13.714 25.143 32.571 30.857 53.714 6.286 22.857 6.286 45.714 0 66.857 17.143 22.857 25.714 49.714 24.571 78.286 0 8-2.286 25.143-8.571 43.429z"
            ></path>
          </svg>
          <span>{{ text16 }}</span>
        </div>
      </div>
    </div>
    <div class="oxygen-container14">
      <div class="oxygen-container15">
        <span class="oxygen-text15">{{ text7 }}</span>
        <span class="oxygen-text16">{{ text8 }}</span>
      </div>
      <button class="oxygen-button thqButton">{{ button }}</button>
      <button class="oxygen-button1 thqButton">{{ button1 }}</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "Oxygen",
  props: {
    text: {
      type: String,
      default: "Bình dưỡng khí oxy",
    },
    text1: {
      type: String,
      default: "Đã xác nhận",
    },
    text2: {
      type: String,
      default: "Aashish",
    },
    button: {
      type: String,
      default: "Close",
    },
    button1: {
      type: String,
      default: "Give Feedback",
    },
    text3: {
      type: String,
      default: "Mumbai City",
    },
    text4: {
      type: String,
      default:
        "Bhayandar, West Mumbai. Shree Parshwprem Murti Pujak Jain Sangh, 90 feet road, Opp. SL Porwal School, Bhayandar West.",
    },
    text5: {
      type: String,
      default: "Checked on: ",
    },
    text6: {
      type: String,
      default: "19/06/21 08:11 PM",
    },
    text7: {
      type: String,
      default: "Verified and Available",
    },
    text8: {
      type: String,
      default: "Verified and Unavailable",
    },
    text9: {
      type: String,
      default: "Số lượng: ",
    },
    text10: {
      type: String,
      default: "available",
    },
    text11: {
      type: String,
      default: "Giá:",
    },
    text12: {
      type: Number,
      default: "NA",
    },
    text13: {
      type: String,
      default: "9870644158",
    },
    text14: {
      type: String,
      default: "Rapid Leads",
    },
    text15: {
      type: String,
      default: "0",
    },
    text16: {
      type: String,
      default: "0",
    },
  },
};
</script>

<style scoped>
.oxygen-oxygen {
  width: 70%;
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  padding-top: var(--dl-space-space-doubleunit);
  grid-row-gap: var(--dl-space-space-unit);
  padding-left: var(--dl-space-space-tripleunit);
  padding-right: var(--dl-space-space-tripleunit);
  flex-direction: column;
  padding-bottom: var(--dl-space-space-doubleunit);
  justify-content: center;
}
.oxygen-container {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-icon {
  width: 24px;
  height: 24px;
  margin-left: auto;
}
.oxygen-container01 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-text02 {
  font-size: 18px;
  font-style: normal;
  font-weight: 700;
}
.oxygen-icon02 {
  width: 24px;
  height: 24px;
  margin-left: auto;
  margin-right: var(--dl-space-space-unit);
}
.oxygen-icon04 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-unit);
  padding-right: 0px;
}
.oxygen-icon06 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-unit);
}
.oxygen-icon08 {
  width: 24px;
  height: 24px;
}
.oxygen-container02 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.oxygen-container03 {
  flex: 0 0 auto;
  width: 50%;
  display: flex;
  align-items: flex-start;
  grid-row-gap: var(--dl-space-space-halfunit);
  flex-direction: column;
  justify-content: center;
}
.oxygen-text04 {
  width: 100%;
  line-height: 2;
}
.oxygen-container04 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-icon10 {
  width: 24px;
  height: 24px;
}
.oxygen-container05 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-icon12 {
  width: 24px;
  height: 24px;
}
.oxygen-container06 {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.oxygen-container07 {
  flex: 0 0 auto;
  display: flex;
  align-items: flex-start;
  flex-direction: row;
}
.oxygen-icon14 {
  width: 24px;
  height: 24px;
}
.oxygen-container08 {
  flex: 0 0 auto;
  display: flex;
  align-items: flex-start;
  flex-direction: row;
}
.oxygen-icon16 {
  width: 24px;
  height: 24px;
}
.oxygen-container09 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-container10 {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-container11 {
  flex: 0 0 auto;
  display: flex;
  column-gap: var(--dl-space-space-doubleunit);
  align-items: center;
  margin-left: auto;
  flex-direction: row;
  justify-content: flex-start;
}
.oxygen-container12 {
  flex: 0 0 auto;
  display: flex;
  align-items: flex-start;
  flex-direction: row;
}
.oxygen-icon18 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-halfunit);
}
.oxygen-container13 {
  flex: 0 0 auto;
  display: flex;
  align-items: flex-start;
  margin-right: var(--dl-space-space-halfunit);
  flex-direction: row;
}
.oxygen-icon20 {
  width: 24px;
  height: 24px;
}
.oxygen-container14 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: space-between;
}
.oxygen-container15 {
  flex: 0 0 auto;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.oxygen-text15 {
  display: none;
  padding-right: var(--dl-space-space-tripleunit);
}
.oxygen-text16 {
  display: none;
  padding-left: var(--dl-space-space-tripleunit);
}
.oxygen-button {
  color: var(--dl-color-gray-white);
  width: 100%;
  display: none;
  font-size: 20px;
  text-align: center;
  border-style: hidden;
  background-color: var(--dl-color-primary-300);
}
.oxygen-button1 {
  color: var(--dl-color-gray-white);
  width: 100%;
  font-size: 20px;
  text-align: center;
  border-style: hidden;
  background-color: var(--dl-color-primary-300);
}
</style>
