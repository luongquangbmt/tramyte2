
<template>
  <router-view />
</template>